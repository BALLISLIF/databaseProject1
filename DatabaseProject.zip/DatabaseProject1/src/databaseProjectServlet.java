
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.SimpleHash;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

/**
 * Servlet implementation class FreeMarkerServlet
 */
@WebServlet("/databaseProjectServlet")
public class databaseProjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Configuration cfg = null;
	private String templateDir = "/WEB-INF/templates";
	//private Query queryClass;
	String query="";
	boolean option1Pressed= false;
	boolean option2Pressed = false;
	boolean option3Pressed = false;
	boolean option4Pressed = false;
	boolean option5Pressed = false;

	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public databaseProjectServlet() {
		super();
		//queryClass = new Query();
	}

	public void init() {
		cfg = new Configuration(Configuration.VERSION_2_3_25);
		cfg.setServletContextForTemplateLoading(getServletContext(), templateDir);
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
	}

	public void runTemplate(HttpServletRequest request, HttpServletResponse response) {
		// You can use this structure for all of your objects to be sent to browser
		Template template = null;
		DefaultObjectWrapperBuilder df = new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_25);
		SimpleHash root = new SimpleHash(df.build());

		//connect to database
		Connection con = DatabaseAccess.connect();
		
    	//select query
		String option1 = request.getParameter("option1");
		String option2 = request.getParameter("option2");
		String option3 = request.getParameter("option3");
		String option4 = request.getParameter("option4");
		String option5 = request.getParameter("option5");

		if (option1!=null){
			query ="select * from employees";
			option1Pressed = true;

		}
		else if (option2!=null){
			query ="SELECT T4.DEPARTMENT_NAME, T4.FEMALE_TO_MALE_RATIOS_THAT_ARE_1_OR_GREATER "
					+ "FROM (SELECT T3.DEPT_NAME AS DEPARTMENT_NAME ,  (T3.AVERAGE_FEMALE_SALARY / T3.AVERAGE_MALE_SALARY)"
					+ " AS FEMALE_TO_MALE_RATIOS_THAT_ARE_1_OR_GREATER  "
					+ "FROM (SELECT T1.DEPT_NAME, T1.AVERAGE_FEMALE_SALARY, T2.AVERAGE_MALE_SALARY "
					+ "FROM (SELECT DEPARTMENTS.DEPT_NAME, SUM(SALARIES.SALARY) /  COUNT(DEPT_EMP.EMP_NO) "
					+ "AS AVERAGE_FEMALE_SALARY "
					+ "FROM DEPARTMENTS NATURAL JOIN DEPT_EMP NATURAL JOIN SALARIES NATURAL JOIN EMPLOYEES WHERE EMPLOYEES.GENDER = 'F' GROUP BY DEPARTMENTS.DEPT_NAME) "
					+ "AS T1, (SELECT DEPARTMENTS.DEPT_NAME, SUM(SALARIES.SALARY)/ COUNT(DEPT_EMP.EMP_NO) AS AVERAGE_MALE_SALARY "
					+ "FROM DEPARTMENTS NATURAL JOIN DEPT_EMP NATURAL JOIN SALARIES NATURAL JOIN EMPLOYEES "
					+ "WHERE EMPLOYEES.GENDER = 'M' GROUP BY DEPARTMENTS.DEPT_NAME) AS T2 GROUP BY T1.DEPT_NAME) AS T3) AS T4 WHERE T4.FEMALE_TO_MALE_RATIOS_THAT_ARE_1_OR_GREATER >=1 ORDER BY T4.FEMALE_TO_MALE_RATIOS_THAT_ARE_1_OR_GREATER DESC;"
;

			option2Pressed = true;

		}
		else if (option3!=null){
			query ="select * from departments";
			option3Pressed = true;

		}
		else if (option4!=null){
			query ="SELECT DEPARTMENTS.DEPT_NAME, employees.birth_date, AVG(SALARIES.SALARY), "
					+ "COUNT(employees.last_name)"+
					"FROM employees"+
					"INNER JOIN dept_emp"+
					"ON dept_emp.emp_no = employees.emp_no"+
					"INNER JOIN departments"+
					"ON departments.dept_no = dept_emp.dept_no"+
					"INNER JOIN salaries"+
					"ON salaries.emp_no = employees.emp_no";

			option4Pressed = true;
		}
		else if (option5!=null){
			query ="SELECT distinct e.emp_no, first_name AS FIRSTNAME,last_name AS LASTNAME,"
					+ "birth_date AS BIRTHDATE "
					+ "FROM employees AS e"
					+"INNER JOIN salaries AS s ON e.emp_no=s.emp_no" 
					+"INNER JOIN dept_manager AS d on e.emp_no=d.emp_no"
					+"WHERE gender='f' AND birth_date<'1990-01-01' AND salary>80000";
			option5Pressed = true;

		}

		ResultSet rs = DatabaseAccess.retrieve(con, query);
		
		List<String> queryData = new ArrayList<>();
		try {
			while(rs.next()) {
				if(option1Pressed==true){
					queryData.add(rs.getString("first_Name"));
				}
				else if(option2Pressed==true){
					queryData.add(rs.getString("dept_name"));
				}
				else if(option3Pressed==true){
					queryData.add(rs.getString("dept_Name"));
				}
				else if(option4Pressed==true){
					queryData.add(rs.getString("first_Name")+ "" + rs.getString("last_Name")+""+rs.getString("salary"));
				}
				else if(option5Pressed==true){
					queryData.add(rs.getString("first_Name")+""+rs.getString("last_Name"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		root.put("queryData", queryData);

		
		//display ftl file
        try {
        	String templateName = "Query.ftl";
			template = cfg.getTemplate(templateName);
			response.setContentType("text/html");
			Writer out = response.getWriter();
			template.process(root, out);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Could not get template name");
		}
		DatabaseAccess.closeConnection(con);

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	runTemplate(request, response);

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
