/**
 * 
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Mehdi
 *
 */
public class Query {
	
	private Map<String, List<String>> queryData;
	private int size;
	
	public Query() {
		queryData = new HashMap<String,List<String>>();
		size  = 0;
	}
	
	public void add(String user, String query) {
		List<String> data = queryData.get(user);
		if (data ==  null) {
			data = new ArrayList<String>();
			data.add(query);
			queryData.put(user, data);
		}else {
			data.add(query);
			queryData.put(user, data);
		}
		size++;
	} // end of add
	
	public List<String> getData(String user) {
		return queryData.get(user);
	} // end of getThoughts

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}
	
	@Override
	public String toString() {
		String result= "";
		for (Map.Entry<String, List<String>> entry : queryData.entrySet()) {
			String user = entry.getKey();
			List<String> qlist = entry.getValue();
			result += user + "\n";
			for (String t : qlist) {
				result += t + "\n";
			}
		} // end of for
		return result;
	}

}
